export default {
  apiGateway: {
	URL: 'https://2zzx2r1eva.execute-api.us-east-1.amazonaws.com/prod',
  },
  cognito: {
    USER_POOL_ID : 'us-east-1_ipv4cDgMq',
    APP_CLIENT_ID : '5qu2kd1f7js5seodkt9h4e5pk1',
    REGION: 'us-east-1',
	IDENTITY_POOL_ID: 'us-east-1_ipv4cDgMq',
  }
};